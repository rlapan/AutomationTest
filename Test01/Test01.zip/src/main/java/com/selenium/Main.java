package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Main {

//    public static void main(String[] args) {
//        // 1. Open the Chrome Browser
//        System.setProperty("webdriver.chrome.driver","E://Automation//chromedriver.exe");
//        WebDriver driver = new ChromeDriver();
//
//        // max the Chrome browser
//        driver.manage().window().maximize();
//
//        // 2. Navigate to the URL
//        driver.get("https://www.joshwoodcolour.com");
//
//        driver.findElement(By.className("header__container")).click();
//
//        driver.findElement(By.className("needsclick CloseButton__StyledSvgInput-sc-1mksxwr-0 fzQmMF kl-private-reset-css-Xuajs1")).click();
//
//        // 3. Close the browser
//        driver.close();
//    }
}