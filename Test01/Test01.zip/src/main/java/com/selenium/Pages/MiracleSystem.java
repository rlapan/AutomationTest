package com.selenium.Pages;

import org.openqa.selenium.WebDriver;

public class MiracleSystem extends MethodsPage {
    public MiracleSystem(WebDriver driver) {
        super(driver);
    }
}
