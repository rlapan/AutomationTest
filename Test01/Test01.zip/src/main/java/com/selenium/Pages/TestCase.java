package com.selenium.Pages;

public class Test extends TestBase{

    public void Test(){
        main.goTo();
        main.findPopup();
        allProducts.click();
    }
}
